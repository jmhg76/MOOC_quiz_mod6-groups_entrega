// Tarea 6: Desarrollar el controlador de grupos

const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const { models } = require("../models");

// Autoload el group asociado a :groupId
exports.load = async(req, res, next, groupId) => {

    try {
        const group = await models.Group.findByPk(groupId); // Simplemente busco el group
        if (group) {
            req.load = {...req.load, group }; // Añado group a req.load
            next();
        } else {
            throw new Error('There is no group with id=' + groupId);
        }
    } catch (error) {
        next(error);
    }
};



// GET /groups
exports.index = async(req, res, next) => {


    try {
        const groups = await models.Group.findAll();
        res.render('groups/index.ejs', { groups });
    } catch (error) {
        next(error);
    }
};

// GET /groups/new
exports.new = (req, res, next) => {

    const group = { name: "" };
    res.render('groups/new', { group });

};




// POST /groups/create
exports.create = async(req, res, next) => {

    const { name } = req.body;

    let group = models.Group.build({ name });

    try {
        // Saves only the name group into the DDBB
        // group = await group.save(); //// Original del video
        group = await group.save({ fields: ["name"] });
        req.flash('success', 'Group created successfully.');
        res.redirect('/groups');
    } catch (error) {
        if (error instanceof Sequelize.ValidationError) {
            req.flash('error', 'There are errors in the form:');
            error.errors.forEach(({ message }) => req.flash('error', message));
            res.render('groups/new', { group });
        } else {
            req.flash('error', 'Error creating a new Group: ' + error.message);
            next(error);
        }
    }
};


// GET /groups/:groupId/edit
//exports.edit = (req, res, next) => { // Original
exports.edit = async(req, res, next) => { // Habrá que poner async ... si el middleware lleva await ...


    const { group } = req.load;
    const allQuizzes = await models.Quiz.findAll();
    // getQuizzes se genera automáticamente por haber establecido la relación N-to-N en el modelo
    // .map(quiz => quiz.id); ... devuelve del array completo sólo los ids

    // Viene en Video 01:22:00 ... de Tarea 3: Definir el modelo Group. // Relation N-to-N between Group and Quiz:
    // es la propiedad get ' as: 'quizzes', '
    const groupQuizzesIds = await group.getQuizzes().map(quiz => quiz.id);
    res.render('groups/edit', { group, allQuizzes, groupQuizzesIds });


};


// PUT /groups/:groupId
exports.update = async(req, res, next) => {

    const { group } = req.load;

    const { name, quizzesIds = [] } = req.body;

    group.name = name.trim();

    try {

        await group.save({ fields: ["name"] });
        // setQuizzes se genera automáticamente por haber establecido la relación N-to-N en el modelo
        // Viene en Video 01:27:00 ... de Tarea 3: Definir el modelo Group. // Relation N-to-N between Group and Quiz:
        // es la propiedad set ' as: 'quizzes', '
        await group.setQuizzes(quizzesIds);

        req.flash('success', 'Group edited successfully.');
        res.redirect('/groups');

    } catch (error) {
        if (error instanceof Sequelize.ValidationError) {
            req.flash('error', 'There are errors in the form:');
            error.errors.forEach(({ message }) => req.flash('error', message));
            // Si hay error pasamos los mismos parámetros que en el middleware edit ...
            // ... pero las tengo que recuperar todas
            const allQuizzes = await models.Quiz.findAll();
            // OJO comn el apaño del tercer parámetro
            res.render('groups/edit', { group, allQuizzes, groupQuizzesIds: quizzesIds });
        } else {
            req.flash('error', 'Error editing the Group: ' + error.message);
            next(error);
        }
    }
};

// DELETE /groups/:groupId
exports.destroy = async(req, res, next) => {

    try {
        await req.load.group.destroy();
        req.flash('success', 'Group deleted successfully.');
        res.redirect('/goback');
    } catch (error) {
        req.flash('error', 'Error deleting the Group: ' + error.message);
        next(error);
    }
};


// GET /groups/:groupId/randomplay
exports.randomPlay = async(req, res, next) => {


    const group = req.load.group;

    // TODO
    // .. 
    // req.session ... añadir una propiedad que guarde los id ya consultados 
    // ... para añadirnos al una consulta tipo NotInt en las opciones del where

    req.session.groupPlay = req.session.groupPlay || {};
    // Mejor tratamos la sesión con un objetos del siguiente modo:
    // Usamos la natoación de array porque tenemos un id para cada group
    req.session.groupPlay[group.id] = req.session.groupPlay[group.id] || {
        resolved: [], // Array que contendrá los Ids de los quizzes ya resueltos para no repetirlos
        // Vacío inicialmente para que sea un falsy
        lastQuizId: 0 // Mejora opcional: Recordamos cual fue el último quiz para que al recargar salga el mismo
            // 0 Inicialmente para que sea un falsy        
    }

    // Quiz a recuperar o bien de la sesion o bien la BDD
    let quiz;


    if (req.session.groupPlay[group.id].lastQuizId) { // ... Antes req.session.randomPlayLastQuizId
        // ... siempre pregunto por el mismo quiz ... si recargo
        quiz = await models.Quiz.findByPk(req.session.groupPlay[group.id].lastQuizId);
    } else {
        // countQuizzes(); propiedad disponible debido a la relación N-to-N entre Group y Quiz
        const total = await group.countQuizzes();
        const quedan = total - req.session.groupPlay[group.id].resolved.length;

        quiz = await models.Quiz.findOne({
            where: {
                'id': {
                    [Sequelize.Op.notIn]: req.session.groupPlay[group.id].resolved
                }
            },
            include: [{ // Inclumos sólo los quiz del group en juego
                model: models.Group,
                as: "groups",
                where: { 'id': group.id }
            }],
            offset: Math.floor(Math.random() * quedan)
        });
    }
    // Todos los quizzes acertados son los que están en éste Array 
    const score = req.session.groupPlay[group.id].resolved.length;

    if (quiz) { // Si se devuelve algún quiz pendiente de contestar ...
        req.session.groupPlay[group.id].lastQuizId = quiz.id; // ... lo guardamos para sabre que nos preguntaron
        // ... render a la vista de jugar aleatorio, pasando el quiz a preguntar y el score "la puntuación" actual, que es lo que necesita la vista
        res.render('groups/random_play', { group, quiz, score });
    } else { // Si NO hay más quiz ...
        delete req.session.groupPlay[group.id]; // ... borro la variable de sesión que guarda lo que acerté ...
        res.render('groups/random_nomore', { group, score }); // ... rendierizo la vista acabé de jugar pasando el score "la puntuación" final 
    }

}


// GET /groups/:groupsId/randomcheck/:quizId(\\d+)
exports.randomCheck = async(req, res, next) => {

    const group = req.load.group;

    // TODO
    // .. 
    // req.session ... añadir una propiedad que guarde los id ya consultados 
    // ... para añadirnos al una consulta tipo NotInt en las opciones del where

    req.session.groupPlay = req.session.groupPlay || {};
    // Mejor tratamos la sesión con un objetos del siguiente modo:
    // Usamos la natoación de array porque tenemos un id para cada group
    req.session.groupPlay[group.id] = req.session.groupPlay[group.id] || {
        resolved: [], // Array que contendrá los Ids de los quizzes ya resueltos para no repetirlos
        // Vacío inicialmente para que sea un falsy
        lastQuizId: 0 // Mejora opcional: Recordamos cual fue el último quiz para que al recargar salga el mismo
            // 0 Inicialmente para que sea un falsy        
    }

    const answer = req.query.answer || ""; // Aquí es donde está la respuesta que dio el usuario
    const { quiz } = req.load; // Aquí es donde está la respuesta correcta

    const result = answer.toLowerCase().trim() === quiz.answer.toLowerCase().trim();

    if (result) { // ... Hemos acertado ...
        // req.session.groupPlay[group.id].lastQuizId lo podemos borrar para que nos pregunten uno nuevo
        req.session.groupPlay[group.id].lastQuizId = 0;

        // Añadimos al req.session.groupPlay[group.id].resolved el Id del Quiz que hemos acertado
        if (req.session.groupPlay[group.id].resolved.includes(quiz.id) === false) { // Sin repetir los Ids
            req.session.groupPlay[group.id].resolved.push(quiz.id);
        }

        // Todos los quizzes acertados son los que están en éste Array 
        const score = req.session.groupPlay[group.id].resolved.length;

        // Renderizamos la vista de que hemos acertado, la respuesta que dimos y con la nueva puntuación
        res.render('groups/random_result', { group, result, answer, score });
    } else { // ... NO hemos acertado ... 
        // Todos los quizzes acertados son los que están en éste Array 
        const score = req.session.groupPlay[group.id].resolved.length;
        // Destruir la propiedad req.session.randomPlayResolved para volver al estado inicial,
        delete req.session.groupPlay[group.id];
        // y renderizar la vista quizzes/random_result.ejs con los parámetros adecuados.
        res.render('groups/random_result', { group, result, answer, score });
    }

}