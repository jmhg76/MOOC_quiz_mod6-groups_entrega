// Tarea 3: Definir el modelo Group.
const { Model } = require('sequelize');

// Definition of the Group model:

module.exports = (sequelize, DataTypes) => {

    class Group extends Model {}

    Group.init({
        name: {
            type: DataTypes.STRING,
            unique: true,
            validate: { notEmpty: { msg: "Group name must not be empty" } }
        }
    }, {
        sequelize
    });

    return Group;
};